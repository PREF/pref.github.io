/****************************************************************************
** Meta object code from reading C++ file 'qhexdocument.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../PREF/qhexedit/document/qhexdocument.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qhexdocument.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QHexDocument_t {
    QByteArrayData data[40];
    char stringdata0[384];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QHexDocument_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QHexDocument_t qt_meta_stringdata_QHexDocument = {
    {
QT_MOC_LITERAL(0, 0, 12), // "QHexDocument"
QT_MOC_LITERAL(1, 13, 14), // "canUndoChanged"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 14), // "canRedoChanged"
QT_MOC_LITERAL(4, 44, 15), // "documentChanged"
QT_MOC_LITERAL(5, 60, 18), // "baseAddressChanged"
QT_MOC_LITERAL(6, 79, 4), // "undo"
QT_MOC_LITERAL(7, 84, 4), // "redo"
QT_MOC_LITERAL(8, 89, 3), // "cut"
QT_MOC_LITERAL(9, 93, 4), // "copy"
QT_MOC_LITERAL(10, 98, 5), // "paste"
QT_MOC_LITERAL(11, 104, 6), // "insert"
QT_MOC_LITERAL(12, 111, 9), // "integer_t"
QT_MOC_LITERAL(13, 121, 6), // "offset"
QT_MOC_LITERAL(14, 128, 1), // "b"
QT_MOC_LITERAL(15, 130, 7), // "replace"
QT_MOC_LITERAL(16, 138, 4), // "data"
QT_MOC_LITERAL(17, 143, 6), // "remove"
QT_MOC_LITERAL(18, 150, 3), // "len"
QT_MOC_LITERAL(19, 154, 13), // "highlightFore"
QT_MOC_LITERAL(20, 168, 11), // "startoffset"
QT_MOC_LITERAL(21, 180, 9), // "endoffset"
QT_MOC_LITERAL(22, 190, 1), // "c"
QT_MOC_LITERAL(23, 192, 13), // "highlightBack"
QT_MOC_LITERAL(24, 206, 18), // "highlightForeRange"
QT_MOC_LITERAL(25, 225, 6), // "length"
QT_MOC_LITERAL(26, 232, 18), // "highlightBackRange"
QT_MOC_LITERAL(27, 251, 7), // "comment"
QT_MOC_LITERAL(28, 259, 1), // "s"
QT_MOC_LITERAL(29, 261, 12), // "commentRange"
QT_MOC_LITERAL(30, 274, 17), // "clearHighlighting"
QT_MOC_LITERAL(31, 292, 13), // "clearComments"
QT_MOC_LITERAL(32, 306, 13), // "clearMetadata"
QT_MOC_LITERAL(33, 320, 13), // "beginMetadata"
QT_MOC_LITERAL(34, 334, 11), // "endMetadata"
QT_MOC_LITERAL(35, 346, 4), // "read"
QT_MOC_LITERAL(36, 351, 6), // "saveTo"
QT_MOC_LITERAL(37, 358, 10), // "QIODevice*"
QT_MOC_LITERAL(38, 369, 6), // "device"
QT_MOC_LITERAL(39, 376, 7) // "isEmpty"

    },
    "QHexDocument\0canUndoChanged\0\0"
    "canRedoChanged\0documentChanged\0"
    "baseAddressChanged\0undo\0redo\0cut\0copy\0"
    "paste\0insert\0integer_t\0offset\0b\0replace\0"
    "data\0remove\0len\0highlightFore\0startoffset\0"
    "endoffset\0c\0highlightBack\0highlightForeRange\0"
    "length\0highlightBackRange\0comment\0s\0"
    "commentRange\0clearHighlighting\0"
    "clearComments\0clearMetadata\0beginMetadata\0"
    "endMetadata\0read\0saveTo\0QIODevice*\0"
    "device\0isEmpty"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QHexDocument[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x06 /* Public */,
       3,    0,  155,    2, 0x06 /* Public */,
       4,    0,  156,    2, 0x06 /* Public */,
       5,    0,  157,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,  158,    2, 0x0a /* Public */,
       7,    0,  159,    2, 0x0a /* Public */,
       8,    0,  160,    2, 0x0a /* Public */,
       9,    0,  161,    2, 0x0a /* Public */,
      10,    0,  162,    2, 0x0a /* Public */,
      11,    2,  163,    2, 0x0a /* Public */,
      15,    2,  168,    2, 0x0a /* Public */,
      11,    2,  173,    2, 0x0a /* Public */,
      15,    2,  178,    2, 0x0a /* Public */,
      17,    2,  183,    2, 0x0a /* Public */,
      19,    3,  188,    2, 0x0a /* Public */,
      23,    3,  195,    2, 0x0a /* Public */,
      24,    3,  202,    2, 0x0a /* Public */,
      26,    3,  209,    2, 0x0a /* Public */,
      27,    3,  216,    2, 0x0a /* Public */,
      29,    3,  223,    2, 0x0a /* Public */,
      30,    0,  230,    2, 0x0a /* Public */,
      31,    0,  231,    2, 0x0a /* Public */,
      32,    0,  232,    2, 0x0a /* Public */,
      33,    0,  233,    2, 0x0a /* Public */,
      34,    0,  234,    2, 0x0a /* Public */,
      35,    2,  235,    2, 0x0a /* Public */,
      36,    1,  240,    2, 0x0a /* Public */,
      39,    0,  243,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12, QMetaType::UChar,   13,   14,
    QMetaType::Void, 0x80000000 | 12, QMetaType::UChar,   13,   14,
    QMetaType::Void, 0x80000000 | 12, QMetaType::QByteArray,   13,   16,
    QMetaType::Void, 0x80000000 | 12, QMetaType::QByteArray,   13,   16,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12,   13,   18,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QColor,   20,   21,   22,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QColor,   20,   21,   22,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QColor,   13,   25,   22,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QColor,   13,   25,   22,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QString,   20,   21,   28,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12, QMetaType::QString,   13,   25,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QByteArray, 0x80000000 | 12, 0x80000000 | 12,   13,   18,
    QMetaType::Bool, 0x80000000 | 37,   38,
    QMetaType::Bool,

       0        // eod
};

void QHexDocument::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QHexDocument *_t = static_cast<QHexDocument *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->canUndoChanged(); break;
        case 1: _t->canRedoChanged(); break;
        case 2: _t->documentChanged(); break;
        case 3: _t->baseAddressChanged(); break;
        case 4: _t->undo(); break;
        case 5: _t->redo(); break;
        case 6: _t->cut(); break;
        case 7: _t->copy(); break;
        case 8: _t->paste(); break;
        case 9: _t->insert((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< uchar(*)>(_a[2]))); break;
        case 10: _t->replace((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< uchar(*)>(_a[2]))); break;
        case 11: _t->insert((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 12: _t->replace((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 13: _t->remove((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2]))); break;
        case 14: _t->highlightFore((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QColor(*)>(_a[3]))); break;
        case 15: _t->highlightBack((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QColor(*)>(_a[3]))); break;
        case 16: _t->highlightForeRange((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QColor(*)>(_a[3]))); break;
        case 17: _t->highlightBackRange((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QColor(*)>(_a[3]))); break;
        case 18: _t->comment((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 19: _t->commentRange((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 20: _t->clearHighlighting(); break;
        case 21: _t->clearComments(); break;
        case 22: _t->clearMetadata(); break;
        case 23: _t->beginMetadata(); break;
        case 24: _t->endMetadata(); break;
        case 25: { QByteArray _r = _t->read((*reinterpret_cast< integer_t(*)>(_a[1])),(*reinterpret_cast< integer_t(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QByteArray*>(_a[0]) = _r; }  break;
        case 26: { bool _r = _t->saveTo((*reinterpret_cast< QIODevice*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 27: { bool _r = _t->isEmpty();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 26:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QIODevice* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QHexDocument::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QHexDocument::canUndoChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (QHexDocument::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QHexDocument::canRedoChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (QHexDocument::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QHexDocument::documentChanged)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (QHexDocument::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QHexDocument::baseAddressChanged)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject QHexDocument::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QHexDocument.data,
      qt_meta_data_QHexDocument,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QHexDocument::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QHexDocument::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QHexDocument.stringdata0))
        return static_cast<void*>(const_cast< QHexDocument*>(this));
    return QObject::qt_metacast(_clname);
}

int QHexDocument::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    }
    return _id;
}

// SIGNAL 0
void QHexDocument::canUndoChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void QHexDocument::canRedoChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void QHexDocument::documentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void QHexDocument::baseAddressChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
